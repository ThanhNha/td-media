<?php /* Template Name: Page News */?>
<?php get_header(); ?>

<?php the_post();?>

<?php get_template_part('site-structure/page/page-news/index');?>

<?php get_footer(); ?>