<?php get_header(); ?>

<?php get_template_part( 'site-structure/page/404/index' );?>

<?php get_footer(); ?>