<section id="contact-ss1" class="contact-ss1 bg-img">
    <div class="banner overlay bg-bottom bg-no-repeat bg-cover" style="background-color: rgb(220, 208, 194); background-image: url(&quot;<?php if ( get_field('background') ) {
               the_field('background');
            }?>&quot;);">
    </div>
</section>