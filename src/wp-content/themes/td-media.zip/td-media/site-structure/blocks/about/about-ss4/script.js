function about_ss4() {
  $(".counter ").counterUp({
    delay: 15,
    time: 3000,
  });
}
