<main id="page">
    <div class="app">
        <?php the_content(); ?>
    </div>
</main>