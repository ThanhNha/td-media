<?php get_header(); ?>

<?php the_post();?>

<?php get_template_part('site-structure/page/page/index'); ?>

<?php get_footer(); ?>